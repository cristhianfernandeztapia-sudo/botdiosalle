# DiosAlleBot
Bot privado Telegram creado para uso íntimo y artístico.